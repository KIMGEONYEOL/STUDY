package product.view;

import java.util.*;
import product.model.dao.*;
import product.model.vo.*;

public class ProductView
{
	private Scanner sc = new Scanner(System.in);
	
	public ProductView(){}
	
	public void displayMenu()
	{
		int no;
		
		do{
			System.out.println();
			System.out.println("상품 관리 프로그램");
			System.out.println("1. 전체 조회");
			System.out.println("2. 추가");
			System.out.println("3. 수정");
			System.out.println("4. 삭제");
			System.out.println("5. 검색");
			System.out.println("6. 끝내기");
			System.out.print("번호 선택 : ");
			no = sc.nextInt();
			
			switch(no)
			{
			case 1:	displayList();		break;
			case 2:	displayInsert();		break;
			case 3:	displayUpdate();	break;
			case 4:	displayDelete();	break;
			case 5:	displayRowName();	break;
			case 6:	System.out.println("프로그램을 종료합니다.");
					return;
			default:	System.out.println("번호가 잘못 입력되었습니다.");
			        System.out.println("다시 입력하십시오...");
			}
		
		}while(true);
	}
	
	public void displayList()
	{
		ProductDao pDao = new ProductDao();
		
		ArrayList<Product> alist = pDao.selectAll();
		
		System.out.println("조회된 전체 행 수 : " + alist.size());
		for(Product p : alist)
			System.out.println(p);
	}
	
	public void displayRow()
	{
		ProductDao pDao = new ProductDao();
		
		System.out.print("조회할 상품 아이디 : ");
		String pID = sc.next();
		
		Product p = pDao.selectID(pID);
		
		System.out.println();
		System.out.println("조회된 상품 정보는 아래와 같습니다...");
		System.out.println(p);
	}
	
	public void displayRowName()
	{
		ProductDao pDao = new ProductDao();
		
		System.out.print("검색할 상품명 : ");
		sc.nextLine();
		String pName = sc.nextLine();
		
		ArrayList<Product> alist = pDao.selectName(pName);
		
		System.out.println();
		System.out.println("검색된 행 수 : " + alist.size());
		for(Product p : alist)
			System.out.println(p);
	}
	
	public void displayInsert()
	{
		ProductDao pDao = new ProductDao();
		Product p = new Product();
		
		System.out.println("새로운 상품정보를 입력하십시오...");
		System.out.print("상품 아이디 : ");
		p.setProductID(sc.next());
		System.out.print("상품명 : ");
		sc.nextLine();
		p.setpName(sc.nextLine());
		System.out.print("가격 : ");
		p.setPrice(sc.nextInt());
		System.out.print("상품설명 : ");
		sc.nextLine();
		p.setDescription(sc.nextLine());
		
		int result = pDao.insertRow(p);
		
		if(result > 0){
			System.out.println("insert success....");
			displayRow();
		}else
			System.out.println("insert failed...");
	}
	
	public void displayUpdate()
	{
		ProductDao pDao = new ProductDao();
		
		displayRow();
		
		System.out.print("수정할 상품의 아이디 : ");
		String pID = sc.next();
		System.out.print("수정할 가격 : ");
		int price = sc.nextInt();
		
		int result = pDao.updateRow(pID, price);
		
		if(result > 0)
			System.out.println("update success....");
		else
			System.out.println("update failed...");
	}
	
	public void displayDelete()
	{
		ProductDao pDao = new ProductDao();

		displayRow();
		
		System.out.print("삭제할 상품의 아이디 : ");
		String pID = sc.next();
				
		int result = pDao.deleteRow(pID);
		
		if(result > 0)
			System.out.println("delete success....");
		else
			System.out.println("delete failed...");
	}
}

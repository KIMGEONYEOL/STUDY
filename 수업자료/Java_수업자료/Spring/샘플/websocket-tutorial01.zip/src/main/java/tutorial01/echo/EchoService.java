package tutorial01.echo;

public interface EchoService {
    String getMessage(String message);
}

package collection.controller;

public class MapSample {

}

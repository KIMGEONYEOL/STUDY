package collection.start;

import collection.view.Menu;

public class Main {

	public static void main(String[] args) {
		// Collection (컬렉션 프레임워크) 테스트용
		Menu.display();
	}

}

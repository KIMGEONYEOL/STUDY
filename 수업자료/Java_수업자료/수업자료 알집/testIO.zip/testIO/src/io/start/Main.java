package io.start;

import io.view.Menu;

public class Main {
	public static void main(String[] args) {
		//입출력 클래스 테스트용
		Menu.display();
	}
}

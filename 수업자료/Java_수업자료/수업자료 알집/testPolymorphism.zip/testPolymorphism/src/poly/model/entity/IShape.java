package poly.model.entity;

public interface IShape {
	double area();
	double perimeter();
}

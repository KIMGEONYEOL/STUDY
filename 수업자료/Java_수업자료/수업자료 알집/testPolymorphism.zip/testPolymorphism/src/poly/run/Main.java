package poly.run;

import poly.view.Menu;

public class Main {

	public static void main(String[] args) {
		// 다형성 테스트 프로젝트 실행용
		Menu.display();
	}

}

package test.abst;

public interface Grade {
	//추상메소드로만 구성된 추상클래스
	char getGrade(int score);  //public abstract 표기 생략할 수 있음
	//public abstract char getGrade(int score);
}
